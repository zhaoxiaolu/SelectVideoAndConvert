//
//  ViewController.h
//  SelectVideoAndConvert
//
//  Created by macavilang on 16/7/4.
//  Copyright © 2016年 Snoopy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

